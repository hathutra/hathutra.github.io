
 const view={}
 view.show = async function(name){
 if (name=="alljob"){
    let app=document.getElementById("app")
    app.innerHTML=component.head+component.alljob
    view.nextLink()
    await controller.loadJob()
    view.showjob()
 }

 if(name=="allcompany"){
    let app=document.getElementById("app")
    app.innerHTML=component.head+component.allcompany
    view.nextLink()
    
await controller.loadCompany()
    view.showCompany()
    


 }
  if(name=="postJob"){
 let app=document.getElementById("app")
 app.innerHTML=component.head+component.postJob
 view.nextLink()
 await controller.loadCompany()
 getOption()

 
 let form = document.getElementById('form-postjob')
form.onsubmit = postjobHandler

function postjobHandler(event) {

    event.preventDefault()

    let job = {
        nameCompany: form.nameCompany.value,
        title: form.title.value,
        money: form.money.value,
        address: form.address.value,
        skill: form.skill.value,
        description: form.description.value,
        SandE: form.SandE.value,
        why: form.why.value
    }
    console.log(job);

    let validateResult = [
        view.validate(
            job.title,
            'job-title-error',
            'Invalid title!'
        ),
        view.validate(
            job.money,
            'job-money-error',
            'Invalid title!'
        ),
        view.validate(
            job.address,
            'job-address-error',
            'Invalid address!'
        ),
        view.validate(
            job.skill,
            'job-skill-error',
            'Invalid employee!'
        ),
        view.validate(
            job.description,
            'job-description-error',
            'Invalid description!'
        ),
        view.validate(
            job.SandE,
            'job-SandE-error',
            'Invalid title!'
        ),
        view.validate(
            job.why,
            'why-error',
            'Invalid title!'
        ),
    ]
    if (allPassed(validateResult)) {
        controller.postjob(job)
    }
}
 }
 if(name=="postCompany"){
    let app=document.getElementById("app")
    app.innerHTML=component.head+component.postCompany
    view.nextLink()

    
    let form = document.getElementById('form-postcompanny')
form.onsubmit = postcompanyHandler

let img = {};

async function postcompanyHandler(event) {

    event.preventDefault()

    try {
        let logofiles = form.logoCompany.files
        let logofile = logofiles[0]
        let bgfiles = form.bgCompany.files
        let bgfile = bgfiles[0]
        if (!logofile) {
            throw new Error('Choose your Logo image!')
        }
        if (!bgfile) {
            throw new Error('Choose your IMG description image!')
        }
        let linklogo = await upload(logofile)
        let linkbg = await upload(bgfile)
        imglink(linklogo, linkbg)
      

    } catch (error) {
        alert(error.message)
    }


    let company = {
        logo: img.linkLogo,
        bg: img.linkBG,
        name: form.name.value,
        address: form.address.value,
        employee: form.employee.value,
        title: form.title.value,
        description: form.description.value,
    }
    console.log(company);

    let validateResult = [
        view.validate(
            company.name,
            'name-error',
            'Invalid name!'
        ),
        view.validate(
            company.address,
            'address-error',
            'Invalid address!'
        ),
        view.validate(
            company.employee,
            'employee-error',
            'Invalid employee!'
        ),
        view.validate(
            company.title,
            'title-error',
            'Invalid title!'
        ),
        view.validate(
            company.description,
            'description-error',
            'Invalid description!'
        )
    ]
    if (allPassed(validateResult)) {
        controller.postcompany(company)
    }
}


async function upload(file) {
    let fileName = Date.now() + file.name
    let filePath = `logo/${fileName}`
    let fileRef = firebase.storage().ref().child(filePath)
    await fileRef.put(file)
    let link = getFlileUrl(fileRef)
    return link
}

function getFlileUrl(fileRef) {
    return `https://firebasestorage.googleapis.com/v0/b/${fileRef.bucket}/o/${encodeURIComponent(fileRef.fullPath)}?alt=media`
}

function imglink(imgLogo, imgBG){
    img.linkLogo = imgLogo;
    img.linkBG = imgBG;
}
    }

 if(name=="detail"){
    let app=document.getElementById("app")
    app.innerHTML=component.head+component.detail
    view.nextLink()
    view.showCompanyDetail()
    view.showJobDetail()

 }
 }


 view.showCompany = function () {
    let listCompany = document.getElementById("listComponys")
  
    if (model.companys) {
      companys = model.companys
  
      for (let company of companys) {
      
        let name = company.name
        let nameId = name.replace(' ', '')
  
        let logo = company.logo
  
        let cardCompany = `<div class="col-md-4 ">
    <div class="card rounded  ">
      <img src="${logo}" class="card-img" alt="...">
      <div class="pd10">
        <p  style="text-align: center;">${name}</p>
      </div>
      <div class="p-2 d-flex justify-content-between">
  
      <button style="padding: 5px 30px 5px 30px; border-radius: 5px" class="fs18 save">Delete</button>
        <a onclick=linkCompanyDetail('${nameId}') href="#" style=" color:#013B80;font-size: 12px;"> xem thêm >> </a>
      </div>
    </div>
  </div>`
        view.appendHtml(listCompany, cardCompany)
      }
  
  
    }
  }


  view.showCompanyDetail = function () {

    let companydetail = document.getElementById("detail")
    if (model.companys) {
      companys = model.companys
      for (let company of companys) {
  
        let nameId = company.name.replace(' ', '')
        if (model.companyId == nameId) {
          let name = company.name
  
          let companyDetail = ` 
        <div style="margin-right: 10px" class="logo-cty col-sm-3">
            <div>
                <img style="max-width: 100%" src="${company.logo}" alt="">
                <div>
                    <div style="text-align: center; padding-bottom: 20px"><span class="fw500 fs20">${name}</span></div>
                    <div style="padding-bottom: 10px"><i class="fas fa-map-marker-alt"></i><span>&nbsp;${company.address}</span>
                    </div>
                    <div style="padding-top: 20px"><i class="fas fa-users"></i><span>&nbsp;${company.employee}+</span></div>
                </div>
            </div>
        </div>
        <div class="about col-sm-8">
        <div class="row">
        <div class="col-md-10">
            <div class="img-jd">
                <img style="max-width: 100%; border: 5px solid #C4C4C4;" src="${company.bg}" alt="">
            </div>
            <div class="pt0">
           
            
                <div style="text-align: center">
                    <span class="fw500 fs20">${company.title}</span>
                
                </div>
               
                <div>
                    <p>&nbsp;&nbsp;&nbsp;&nbsp; ${company.description}</p>
                </div>
            </div>
            </div>
            <div class="col-md-2">
            <button class="btn-sj">EDIT</button>
           </div>
            
      
        </div>`
          view.appendHtml(companydetail, companyDetail)
          break;
        }
      }
    }
  }


  view.showjob = function () {
    let listJob = document.getElementById("job")
  
    if (model.jobs) {
      jobs = model.jobs
      for (let job of jobs) {


         if(model.companys){
           companys=model.companys
            for(let company of companys){
          if(company.name==job.nameCompany){
     
     
  
  
            let jobCompany = `
            <div style="padding: 15px" class="row">
            <div class="col-sm-3">
                <div style="width: 100px; height: 100px;">
                    <img style="max-width: 100%; max-height: 100%" src="${company.logo}" alt="">
                </div>
            </div>
            <div class="col-sm-9">
                <div>
                <a onclick=linkCompanyDetail('${job.id}') >
                <span class="fw500 fs25">${job.title}
                </span>
                </a>
                </div>
                <div>
                    <span style="color: #a50b0b"><i class="fas fa-search-dollar"></i> upto ${job.money}$</span>
                </div>
                <div>
                    <span>${job.description.substr(0, 200)}...</span>
                </div>
                <div>
                    <span style="color: #013B80;" class="fs20"><i class="fas fa-map-marker-alt"></i> ${job.address}
                        </span>
                </div>
                <div class="footer-card">
                    <div>
                        <span class="fs18 skill">${job.skill}</span>
                        <span class="fs18 skill">Business Analyst</span>
                    </div>
                    <div class="">
                    <button style="padding: 0 30px 0 30px; border-radius: 5px" class="fs18 save">Delete</button>
                    <button style="padding: 0 30px 0 30px; border-radius: 5px; background-color: blue;" class="fs18 save">Edit</button>
                    </div>
                </div>
            </div>
        </div>`
  
            view.appendHtml(listJob, jobCompany)
  
  
  
          }
         }
          }
        }
  
      }
    
    }


    view.showJobDetail = function () {

      let jobdetail = document.getElementById("clear")
    
      if (model.jobs) {
        jobs = model.jobs
        for (let job of jobs) {
          if (model.companyId) {
            companyId = model.companyId
            if (companyId === job.id) {
              view.clearHtml("clear")
              if(model.companys){
                companys = model.companys
    
              for (let company of companys) {
                if(company.name===job.nameCompany){
              
              let jobDetail = `
              <div class="about-company">
              <div class="pt30">
                  <span class="fw500 fs25">JOB DETAIL</span>
              </div>
              <div class="detail row">
                  <div style="margin-right: 10px" class="logo-cty col-sm-3">
                      <div>
                          <img style="max-width: 100%" src="${company.logo}" alt="">
                          <div>
                              <div style="text-align: center; padding-bottom: 20px"><span class="fw500 fs20"> ${job.nameCompany}</span></div>
                              <div style="padding-bottom: 10px"><i class="fas fa-map-marker-alt"></i><span>&nbsp;${job.address}</span>
                              </div>
                              <div style="padding-top: 20px"><i class="fas fa-users"></i><span>&nbsp;1000+</span></div>
                          </div>
                      </div>
                  </div>
                  <div class="about col-sm-8">
                     <div class="row">
                         <div class="col-md-8">
                          <p style="font-weight: 500;font-size: 23px;">${job.title}</p>
                         </div>
                         <div class="col-md-4">
                          <button class="btn-sj">EDIT Job</button>
                         </div>
                     </div>
                     <div class="pl20">
                          <div>
                              <span style="color: #a50b0b" class="fs20"><i class="fas fa-search-dollar fs20"></i> upto ${job.money}$</span>
                          </div>
                          <div>
                              <span style="color: #013B80;" class="fs20"><i class="fas fa-map-marker-alt fs20"></i> ${job.address} </span>
                          </div>
                      </div>
                      <div class="pl20 mt20">
                          <span class="fs18 skill">${job.skill}</span>
                          <span class="fs18 skill">Business Analyst</span>
                      </div>
                      <div class="pt20">
                          <div class="pl20">
                              <p style="font-weight: 500;font-size: 23px;">The job</p>
                              <p>
                              ${job.description}
                              </p>
                          </div>
                          <div class="pl20">
                              <p style="font-weight: 500;font-size: 23px;">Your Skills and Experience</p>
                              <p>
                              ${job.SandE}
                              </p>
                          </div>
                          <div class="pl20">
                              <p style="font-weight: 500;font-size: 23px;">Why You'll Love Working Here</p>
                              <p>
                              ${job.why}
                              </p>
                          </div>
                          <!-- Button trigger modal -->
                           
                      </div>
                   </div>
    
                  </div>
              </div>`
              view.appendHtml(jobdetail, jobDetail)
              break;
              }
            }
            }
          }
    
        }
      }
    }
    }
  function linkCompanyDetail(id) {
    model.saveId(id)
    view.show("detail")
  }

  view.nextLink = function () {
    
    let alljob= document.getElementById("link-job")
    alljob.onclick = function () {
      view.show("alljob")
    }
    let allcompany= document.getElementById("link-company")
    allcompany.onclick = function () {
      view.show("allcompany")
    }
    let postj= document.getElementById("link-postj")
    postj.onclick = function () {
      view.show("postJob")
    }
    let postc= document.getElementById("link-postc")
    postc.onclick = function () {
      view.show("postCompany")
    }
  }

  function getOption(){
    let option = document.getElementById('job-nameCompany')
    if(model.companys)
     companys= model.companys
     for (let company of companys) {
    let html = `<option>${company.name}</option>`
    view.appendHtml( option,html)
     }
 }
 view.appendHtml = function (element, html) {
    element.innerHTML += html
  }

view.disable = function (id) {
    document.getElementById(id).setAttribute('disabled', true)
  }
  
  view.enable = function (id) {
    document.getElementById(id).removeAttribute('disabled')
  }
view.setText = function (id, text) {
    document.getElementById(id).innerText = text
  }
  view.clearHtml = function (clr) {
    document.getElementById(clr).innerHTML = ""
  }
 view.validate = function (condition, idErrorTag, messageError) {
    if (condition) {
      view.setText(idErrorTag, '')
      return true
    } else {
      view.setText(idErrorTag, messageError)
      return false
    }
  }

  
  function allPassed(validateResult) {
    for (let result of validateResult) {
      if (!result) {
        return false
      }
    }
    return true
  }