window.onload=init

 function init(){
      view.show('allcompany')
 }