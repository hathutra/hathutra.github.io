
const model = {
    companys: null,
    companyId:null,
    searchJob:null,
    jobs:null
    // currentCompany: null 
  }

model.saveCompany = function(companys) {
    model.companys = companys
    console.log(model.companys);
    
     
  }
  model.saveJob = function(jobs) {
    model.jobs = jobs 
     
  }
  model.saveId = function (companyId) {
    model.companyId = companyId
    console.log(companyId);
   
    
    
  }
  