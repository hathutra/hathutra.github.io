const component={}



component.alljob=`
<div class="  text-job container ">
<h2> Nhà Tuyển Dụng </h2>
</div>
<div class="filter container">
    <div style="display: flex; justify-content: center; padding-top: 46px" class="row">
        <div style="padding: 0px" class="filter-main col-sm-3">
            <div style="max-width: 100%; padding: 15px 35px 10px 50px ; border-bottom: 2px solid #013B80">
                <span style="font-weight: bold; font-size: 25px">BỘ LỌC</span>
            </div>
            <div style="padding: 15px 35px 10px 50px">
                <div style="padding: 10px ">
                    <div class="" style="display:flex">
                    <input name="" type="checkbox">
                    <label for="">tat ca</label>
                    </div>
                    <input name="" type="checkbox"><br>
                    <input name="" type="checkbox"> <br>
                    <input name="" type="checkbox"> <br>
                    <input name="" type="checkbox"><br>
                    <input name="" type="checkbox"><br>
                    <input name="" type="checkbox"><br>
                    <input name="" type="checkbox"><br>
                </div>
            </div>
            <div style="padding: 15px 35px 10px 50px">
                <div style="border-bottom: 1px solid #000000; padding: 10px ">
                    <div style="padding-bottom: 10px">
                        <span style="font-size: 20px">Vị trí</span>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" class="form-check-input" onclick="selecAll2(this)">Tất cả
                        </label>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="checkbox2" class="form-check-input" value="">Option 1
                        </label>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="checkbox2" class="form-check-input" value="">Option 2
                        </label>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="checkbox2" class="form-check-input" value="">Option 3
                        </label>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="checkbox2" class="form-check-input" value="">Option 4
                        </label>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="checkbox2" class="form-check-input" value="">Option 5
                        </label>
                    </div>
                    <div class="form-check">
                        <label class="form-check-label">
                            <input type="checkbox" name="checkbox2" class="form-check-input" value="">Option 6
                        </label>
                    </div>
                </div>
            </div>
            <div style="display: flex; justify-content: center; padding: 60px">
                <button class="filter-btn">Áp dụng</button>
            </div>
        </div>
        <div id="job" style="padding: 0px" class="filter-result col-sm-8">
          
            
            </div>
        </div>
    </div>`
     component.allcompany=`  <div class="  text-job container ">
     <h2> Nhà Tuyển Dụng </h2>
   </div>
   <div class="container">
     <div id="listComponys"class="row mb-5 justify-content-center ">
     </div>`


component.head=`<div class="bg" style="height: 500px;">
<div class="content1">
  <div class="title">
    <h3> TECHFINDER</h1>
      <h5> WEBSTE TÌM VIỆC HÀNG ĐẦU CHO DEVELOPER</h4>
  </div>

  <form class=" d-flex justify-content-center form-search">
    <span class=""
      style=" border-radius: 5px 0px 0px 5px;  background-color: white; height: 50px; width: 30px;"><i
        style="padding-top:65%;" class="fa fa-search"></i></span>
    <input class="ip" name="search" type="search" style="font-size: 20px;" placeholder="Search" aria-label="Search">

    <div class="form-group ">


      <select class="form-control form-control1 form-search ">
        <option>Hà Nội</option>
        <option>Hồ Chí Minh</option>
        <option>Đà Nẵng</option>

      </select>
    </div>

    <button class=" btnBg  form-search " type="submit"> <i class="fas fa-search  "></i> Search</button>

  </form>

  <div class="pt60 tk">

  </div>

  
</div>
</div>
</div>`

 component.postJob=`<div class="container">
 <form id="form-postjob" style="padding-top:100px">
 <div class="form-group">
   <label for="job-company">Company</label>
   <select class="form-control" name="nameCompany" id="job-nameCompany">
     
   </select>
 </div>
 <div class="form-group">
   <label for="job-title">Title </label>
   <input type="text" class="form-control" name="title" id="job-title">
   <div id="job-title-error" class="message-error"></div>
 </div>
 <div class="form-group">
   <label for="job-money"> Mức lương </label>
   <input type="text" class="form-control" name="money" id="job-money">
   <div id="job-money-error" class="message-error"></div>
 </div>
 <div class="form-group">
   <label for="job-address">Address</label>
   <input type="text" class="form-control" name="address" id="job-address">
   <div id="job-address-error" class="message-error"></div>
 </div>
 <div class="form-group">
   <label for="job-skill">Kỹ năng</label>
   <input type="text" class="form-control" name="skill" id="job-skill">
   <div id="job-skill-error" class="message-error"></div>
 </div>
 <div class="form-group">
   <label for="job-description">The Job</label>
   <textarea class="form-control" id="job-description" name="description" rows="4"></textarea>
   <div id="job-description-error" class="message-error"></div>
 </div>
 <div class="form-group">
   <label for="job-SandE">Your Skills and Experience</label>
   <textarea class="form-control" id="job-SandE" name="SandE" rows="4"></textarea>
   <div id="job-SandE-error" class="message-error"></div>
 </div>
 <div class="form-group">
   <label for="why">Why You'll Love Working Here</label>
   <textarea class="form-control" id="why" name="why" rows="4"></textarea>
   <div id="why-error" class="message-error"></div>
 </div>
 <div style="display: flex; justify-content: center; padding: 20px">
   <button id="btn-postjob" type="submit">POST JOB</button>
 </div>
</form>
</div>`

component.postCompany=`<div class="container">
<form id="form-postcompanny" style="padding-top:100px">
<div class="form-group">
  <label for="logo-company">Logo</label>
  <input type="file" class="form-control-file" name="logoCompany" id="logo-company">
  <div id="logo-company-error" class="message-error"></div>
</div>
<div class="form-group">
  <label for="bg-company">IMG description</label>
  <input type="file" class="form-control-file" name="bgCompany" id="bg-company">
  <div id="bg-company-error" class="message-error"></div>
</div>
<div class="form-group">
  <label for="name">Name of company</label>
  <input type="text" class="form-control" name="name" id="name">
  <div id="name-error" class="message-error"></div>
</div>
<div class="form-group">
  <label for="address">Address</label>
  <input type="text" class="form-control" name="address" id="address">
  <div id="address-error" class="message-error"></div>
</div>
<div class="form-group">
  <label for="employee">Employee</label>
  <input type="text" class="form-control" name="employee" id="employee">
  <div id="employee-error" class="message-error"></div>
</div>
<div class="form-group">
  <label for="title">Title</label>
  <textarea class="form-control" id="title" name="title" rows="2"></textarea>
  <div id="title-error" class="message-error"></div>
</div>
<div class="form-group">
  <label for="description">Description</label>
  <textarea class="form-control" id="description" name="description" rows="10"></textarea>
  <div id="description-error" class="message-error"></div>
</div>
<div style="display: flex; justify-content: center; padding: 20px">
  <button id="btn-postcompany" type="submit">POST COMPANY</button>
</div>
</form>
</div>
`


component.detail = ` 
<div id="clear" class="container" >
<div class="about-company">
<div class="pt30">
    <span class="fw500 fs25">ABOUT COMPANY</span>
</div>
<div id="detail"class="detail row">
   
</div>
</div>
<div class="jobs">
<div>
   
</div>
<div>
   
        
      
</div>
</div>
</div>
</div> `