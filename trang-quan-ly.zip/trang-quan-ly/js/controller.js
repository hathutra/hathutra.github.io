
const controller={}

controller.loadCompany = async function() {
  

    let result = await firebase
      .firestore()
      .collection('company')
      .get()
      
      
    let companys=transformDocs(result.docs)
    model.saveCompany(companys)
    
    console.log(companys);
    
   
  }
  
  controller.loadJob = async function() {
    
  
    let result = await firebase
      .firestore()
      .collection('job')
      .get()
      
      
    let jobs=transformDocs(result.docs)
    model.saveJob(jobs)
    console.log(jobs);
  }



  controller.postcompany = async function (company) {

    let name = company.name.toLowerCase()
    let allCompany = await firebase
      .firestore()
      .collection('company')
      //.where('name', '==', name)
      .get()
    let docs = allCompany.docs
    for (let doc of docs) {
      let data = transformDoc(doc)
      //console.log(data)
      let dataName = data.name.toLowerCase()
      if (dataName == name) {
        alert('company existed!')
        return
      }
    }
  
    view.disable('btn-postcompany')
  
    await firebase
      .firestore()
      .collection('company')
      .add(company)
  
    alert('post company success!')
    document.getElementById('form-postcompanny').name.value = ''
    document.getElementById('form-postcompanny').address.value = ''
    document.getElementById('form-postcompanny').employee.value = ''
    document.getElementById('form-postcompanny').title.value = ''
    document.getElementById('form-postcompanny').description.value = ''
    view.enable('btn-postcompany')
  
  }
  controller.postjob = async function (job) {
    console.log('controller');
    let title = job.title.toLowerCase()
    let alljob = await firebase
      .firestore()
      .collection('job')
      //.where('name', '==', name)
      .get()
    let docs = alljob.docs
    for (let doc of docs) {
      let data = transformDoc(doc)
      //console.log(data)
      let datatitle = data.title.toLowerCase()
      if (datatitle == title) {
        alert('job existed!')
        return
      }
    }
  
    view.disable('btn-postjob')
  
    await firebase
      .firestore()
      .collection('job')
      .add(job)
  
    alert('post job success!')
    document.getElementById('form-postjob').nameCompany.value = ''
    document.getElementById('form-postjob').title.value = ''
    document.getElementById('form-postjob').money.value = ''
    document.getElementById('form-postjob').address.value = ''
    document.getElementById('form-postjob').skill.value = ''
    document.getElementById('form-postjob').description.value = ''
    document.getElementById('form-postjob').SandE.value = ''
    document.getElementById('form-postjob').why.value = ''
    view.enable('btn-postjob')
  
  }
  




function transformDoc(doc) {
    let data = doc.data()
    data.id = doc.id
    return data
  }
  
  function transformDocs(docs) {
    return docs.map(transformDoc)
  }